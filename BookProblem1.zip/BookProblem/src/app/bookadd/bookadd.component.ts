import { Component, OnInit } from '@angular/core';
import data from '../../../src/assets/publisher.json'
import data1 from '../../../src/assets/genre.json';
import { SharedserviceService } from "../../app/sharedservice.service";
@Component({
  selector: 'app-bookadd',
  templateUrl: './bookadd.component.html',
  styleUrls: ['./bookadd.component.css']
})
export class BookaddComponent implements OnInit {

  publisher : any;
  genre : any;
  publishername ;
  genrename;
  price:number;
  bookName:string;
  constructor(private sharedService : SharedserviceService) { }

  ngOnInit() {
    console.log(data);
    this.publisher=data;
    this.genre=data1;
  }

  onSubmit(feedbackform){
    console.log("hi");
    this.sharedService.onSubmit(feedbackform,this.genrename);
  }

  onRowClick1(){
    console.log(this.publishername);
    
  }
  onRowClick2(){
    console.log(this.genrename);
    
  }
}
