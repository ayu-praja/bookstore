import { Injectable } from '@angular/core';
import { Display } from "./display";
import { Observable } from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class SharedserviceService {

  displayList:Display[] = [];
  display:Display;
  constructor() { }

  onSubmit(form,genrename){
    
    
    this.display = new Display(form.value.name,form.value.price,form.value.author,genrename);
    this.displayList.push(this.display);
    console.log(this.displayList);
    
  }

  getDisplay():Display[]{
    return this.displayList;
  }
  
}


