export class Display {
    constructor(
        public name: string,
        public price: number,
        public author: string,
        public genrename: string
    ) { }


}