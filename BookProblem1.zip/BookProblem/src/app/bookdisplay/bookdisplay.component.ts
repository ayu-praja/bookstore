import { Component, OnInit } from '@angular/core';
import { SharedserviceService } from "../../app/sharedservice.service";
import { Display } from "../../app/display";
@Component({
  selector: 'app-bookdisplay',
  templateUrl: './bookdisplay.component.html',
  styleUrls: ['./bookdisplay.component.css']
})
export class BookdisplayComponent implements OnInit {

  details: Display[] = [];
  constructor(private sharedService : SharedserviceService) { }

  ngOnInit() {
    this.details = this.sharedService.getDisplay();
    console.log(this.details);
    
  }

}
